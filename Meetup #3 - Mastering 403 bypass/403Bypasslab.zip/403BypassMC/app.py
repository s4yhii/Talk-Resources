import unicodedata
from flask import Flask, request, Response

app = Flask(__name__)

@app.route('/admin', methods=['GET'])
def admin():
    return Response(str({"url": request.url, "flag": "f4k3_fl4g_f0r_t35t1ng"}), mimetype="application/json")

@app.route('/debug/<path:path>', methods=['GET'])
def debug(path):
    nginx_path = request.url
    flask_path = request.path 

    unicode_normalized_path = unicodedata.normalize('NFKC', path)

    data = {
        "nginx_received_path": nginx_path,
        "flask_interpreted_path": flask_path, 
        "unicode_normalized_path": "/" + unicode_normalized_path 
    }
    return Response(str(data), mimetype="application/json")
if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000)