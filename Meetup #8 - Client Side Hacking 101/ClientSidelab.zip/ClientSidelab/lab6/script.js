 
function secretFunction() {
    const hiddenFlag = "flag{source-map-exposed}";
    console.log("Accessing sensitive function...");
    return hiddenFlag;
}

console.log(secretFunction());
