// flag{lazy-loaded-js}

export function displayFlag() {
    document.getElementById("output").innerText = "Nice work";           
}
