 
function uploadFile() {
    document.getElementById("output").innerText = "Uploading...";
    import("./lazy.js").then(module => {
        module.displayFlag();
    });
}
