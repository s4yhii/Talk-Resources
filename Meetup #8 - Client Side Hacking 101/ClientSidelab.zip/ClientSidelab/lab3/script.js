 
(function() {
    var key = [102, 108, 97, 103, 123, 100, 101, 111, 98, 102, 117, 115, 99, 97, 116, 101, 100, 45, 115, 117, 99, 99, 101, 115, 115, 125];
    var flag = key.map(c => String.fromCharCode(c)).join('');
    
    (function(p, a, c, k, e, d) {
        e = function(c) { return c.toString(36); };
        if (!''.replace(/^/, String)) {
            while (c--) d[c.toString(a)] = k[c] || c.toString(a);
            k = [function(e) { return d[e]; }];
            e = function() { return '\w+'; };
            c = 1;
        }
        while (c--) if (k[c]) p = p.replace(new RegExp('\b' + e(c) + '\b', 'g'), k[c]);
        return p;
    })('2 3=f;4(3);', 5, 5, '|console|var|flag|log'.split('|'), 0, {});
})();
