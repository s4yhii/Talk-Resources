 
function checkUser() {
    let user = document.getElementById("username").value;
    if (user === "admin") {
        document.getElementById("output").innerText = "Access Denied";
    } else {
        document.getElementById("output").innerText = "Welcome, " + user;
    }
}
