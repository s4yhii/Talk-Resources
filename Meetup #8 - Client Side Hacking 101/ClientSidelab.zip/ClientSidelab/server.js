const express = require('express');
const app = express();
const path = require('path');

// Servir cada laboratorio
app.use('/lab1', express.static(path.join(__dirname, 'lab1')));
app.use('/lab2', express.static(path.join(__dirname, 'lab2')));
app.use('/lab3', express.static(path.join(__dirname, 'lab3')));
app.use('/lab4', express.static(path.join(__dirname, 'lab4')));
app.use('/lab5', express.static(path.join(__dirname, 'lab5')));
app.use('/lab6', express.static(path.join(__dirname, 'lab6')));

// Página de inicio estilizada
app.get('/', (req, res) => {
    res.send(`
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <title>Client-Side Hacking Labs</title>
        <style>
          body {
            margin: 0;
            padding: 2rem;
            background: linear-gradient(135deg, #2e2e2e, #4e5d6c);
            font-family: 'Segoe UI', 'Roboto', sans-serif;
            color: #f0f0f0;
          }
          h1 {
            text-align: center;
            color: #ffffff;
          }
          ul {
            list-style-type: none;
            padding: 0;
            max-width: 600px;
            margin: 2rem auto;
          }
          li {
            background: rgba(255, 255, 255, 0.05);
            margin: 0.5rem 0;
            padding: 1rem;
            border-radius: 6px;
            box-shadow: 0 0 5px rgba(0,0,0,0.3);
          }
          a {
            color: #88c4ff;
            text-decoration: none;
            font-size: 1.1rem;
          }
          a:hover {
            color: #a4d1ff;
            text-decoration: underline;
          }
        </style>
      </head>
      <body>
        <h1>🧪 Client-Side 101 Labs</h1>
        <ul>
          <li><a href="/lab1">Lab 1: Breakpoint-Dependent Flag</a></li>
          <li><a href="/lab2">Lab 2: Lazy Loaded JavaScript</a></li>
          <li><a href="/lab3">Lab 3: Deobfuscating Minified JS</a></li>
          <li><a href="/lab4">Lab 4: Normal vs Conditional Breakpoints</a></li>
          <li><a href="/lab5">Lab 5: HTML Sanitization Bypass</a></li>
          <li><a href="/lab6">Lab 6: Source Map Exploitation</a></li>
        </ul>
      </body>
      </html>
    `);
});

// Iniciar servidor
app.listen(3000, () => console.log('🚀 Server running at http://localhost:3000'));
