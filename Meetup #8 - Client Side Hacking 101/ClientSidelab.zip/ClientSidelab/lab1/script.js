 
function execute() {
    let flag = "flag{breakpoint-only}"; // This should only be revealed using a breakpoint
    let hidden = "You need to debug!";
    debugger; // Forces a breakpoint in DevTools
    document.getElementById("output").innerText = hidden; // Modify this manually in DevTools
}
