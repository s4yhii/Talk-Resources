 
function sanitize() {
    let input = document.getElementById("sanitizedInput").value;
    let sanitized = input.replace(/<script.*?>.*?<\/script>/gi, "");
    document.getElementById("sanitizedOutput").innerHTML = sanitized;
}
