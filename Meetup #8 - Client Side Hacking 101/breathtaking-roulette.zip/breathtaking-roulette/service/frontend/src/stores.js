import { writable, derived } from 'svelte/store';

export const shotResult = writable({
    success: null,
    flag: "",
  });

export const gameStatus = writable({
    player_lives: null,
    player_shot: null,
    player_hit: null,

    opponent_lives: null,
    opponent_shot: null,
    opponent_hit: null,
});

// Derived store to check if opponent lives are lower than 0
export const isOpponentDead = derived(gameStatus, $gameStatus => $gameStatus.opponent_lives !== null && $gameStatus.opponent_lives <= 0);

export const isPlayerDead = derived(gameStatus, $gameStatus => $gameStatus.player_lives !== null && $gameStatus.player_lives <= 0);

export const gameOver = writable(false);

export function resetStores() {
    gameStatus.set({
        player_lives: null,
        player_shot: null,
        player_hit: null,

        opponent_lives: null,
        opponent_shot: null,
        opponent_hit: null,
    });
    shotResult.set({
        success: null,
        flag: '',
    });
    gameOver.set(false);
}