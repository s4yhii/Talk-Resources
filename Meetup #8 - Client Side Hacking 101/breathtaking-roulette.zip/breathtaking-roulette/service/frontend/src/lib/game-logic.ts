import { io } from 'socket.io-client';
import { shotResult, gameStatus, isOpponentDead, gameOver, resetStores } from '../stores';

var socket = io({path: '/api/socket.io'});

export const startGame = async () => {
    const response = await fetch('/api/start', {
            method: 'POST',
            mode: 'no-cors',
            credentials: 'include',
        });
        
    const response_data = await response.json();

    socket.emit('join_game', {room: response_data.room});
}

export function makeShot() {
    socket.emit('shot');
}

export function restartGame() {
    resetStores();
    startGame();
}


socket.on('game_status', function(data) {
    gameStatus.set(data);
    shotResult.set({ success: null, flag: '' }) // reset shot result

});

socket.on('game_over', function() {
    gameOver.set(true);
});

socket.on('shot_result', function(data) {
    shotResult.set(data);
});
