<script lang="ts">
    import { onMount } from "svelte";
    import { writable } from "svelte/store";
    import { gameStatus, isOpponentDead, isPlayerDead } from "../../../stores";
    import { goto } from "$app/navigation";
    import { sleep } from '$lib/utils'

    export let classes: string;
    export let gifs: string[];
    export let intervalTime: number;

    let currentGifIndex = writable(0);

    function changeGif() {
        currentGifIndex.update(n => {
        if (n < gifs.length - 1) {
            return n + 1;
        } else {
            clearInterval(intervalTime);

            // предотвращение обнуления выстрела, если пользователь умер
            // если же не обнулять значения, то анимация не повторится при следующих выстрелах
            if (!$isPlayerDead) {
                gameStatus.update(status => {
                    status.player_shot = null;
                    return status;
                });
            } 
            
            if (!$isOpponentDead) {
                gameStatus.update(status => {
                    status.opponent_shot = null;
                    return status;
                });
            }
            return n;
        }
        });
    }

    onMount(() => {
        const interval = setInterval(changeGif, intervalTime);

        return () => {
        clearInterval(interval);
        };
    });
</script>

<div>
    <img class="{classes}" src={gifs[$currentGifIndex]} alt="Animated GIF">
</div>