<script lang="ts">
    import GifAnimation from "$lib/components/animations/GifAnimation.svelte";

    export let character: string;
    export let classes: string;

    let gifs = [
        '/assets/' + character +  '/pose-' + character + '-ready.gif',
        '/assets/' + character +  '/pose-' + character + '-shoot.gif',
        '/assets/' + character +  '/pose-' + character + '-ready-reverse.gif',
        '/assets/' + character +  '/pose-' + character + '-wait.gif',
    ]
</script>

<GifAnimation classes={classes} gifs={gifs} intervalTime={700} />