<script>
    export let text = "Arcade Game!";
    export let classes = "char";
  </script>
  
  <style>
    .container {
      white-space: pre; /* Preserve spaces */
    }

    .char {
      display: inline-block;
      animation: wave 1.5s infinite;
      animation-timing-function: ease-in-out;
    }
  
    @keyframes wave {
      0%, 100% {
        transform: translateY(0);
      }
      50% {
        transform: translateY(-20px);
      }
    }
  </style>
  
  <div class="container">
    {#each text.split('') as char, i}
      <span class={classes} style="animation-delay: {i * 0.1}s;">{char}</span>
    {/each}
  </div>
  