<script lang="ts">
    import { onMount } from "svelte";

    import { resetStores } from "../../../stores";
    import GifAnimation from "$lib/components/animations/GifAnimation.svelte";
    import { goto } from "$app/navigation";

    export let character: string;
    export let classes: string;

    let gifs = [
        '/assets/' + character +  '/pose-' + character + '-wait.gif',
        '/assets/' + character +  '/pose-' + character + '-fall.gif',
    ]

</script>

<GifAnimation classes={classes} gifs={gifs} intervalTime={1200} />