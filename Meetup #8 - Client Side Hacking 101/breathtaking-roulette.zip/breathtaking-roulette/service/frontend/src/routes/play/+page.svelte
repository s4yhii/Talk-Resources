<script lang="ts">
    import { onMount } from 'svelte';
    import { Progressbar } from 'flowbite-svelte';
    import { sineOut } from 'svelte/easing';
    import { fly, fade } from 'svelte/transition';

    import { shotResult, gameStatus, isOpponentDead, isPlayerDead, gameOver, resetStores } from '../../stores';
    import { startGame, restartGame, makeShot } from '$lib/game-logic';

    import TextAnimaiton from '$lib/components/TextAnimaiton.svelte';
	import ShootAnimation from '$lib/components/animations/ShootAnimation.svelte';
	import FallAnimation from '$lib/components/animations/FallAnimation.svelte';

    let canShoot = true;
    const cooldownTime = 2000; // delay перед следующим выстрелом

	let show = true;
	let shouldTranslate = false;
	$: translateAmount = shouldTranslate ? -50 : 0;
    
    function handleSpaceKey(event: KeyboardEvent) {
        if (event.code === 'Space' && canShoot) {
            event.preventDefault(); // Prevent default space bar behavior (like scrolling the page)

            makeShot();
            canShoot = false;

            setTimeout(() => {
                canShoot = true;
            }, cooldownTime);
        }
    }

    onMount(() => {
        window.addEventListener('keydown', handleSpaceKey);

        return () => {
            window.removeEventListener('keydown', handleSpaceKey);
        };
    });
</script>

<div class="relative w-full h-screen">
    <img class="w-full h-full object-cover" src="/assets/bg/bg-play-screen.png" alt="Random">
    {#if $shotResult.flag}
        <div class="absolute inset-x-0 top-0 stroke-text flex flex-col items-center justify-center vt323-regular">
            <p class="text-white text-[3rem] text-center font-bold leading-[6rem]">
                {$shotResult.flag}
        </p>

        </div>
    {/if}
            

    {#if $isPlayerDead}
        <div 
            class="absolute inset-x-0 top-[13rem] stroke-text flex flex-col items-center justify-center vt323-regular"
            in:fade={{delay: 2000, duration: 500}}
            style="--translate: {translateAmount}px">
            <p class="text-white text-[6rem] text-center font-bold leading-[6rem]"
                >
                game over,<br />
                you died from <br />
                <TextAnimaiton text="skill issue" />
            </p>
        </div>
        <div 
            class="absolute inset-x-0 bottom-10 stroke-text flex flex-col items-center justify-end vt323-regular leading-[4.8rem]"
            in:fade={{delay: 3400, duration: 500}}
            style="--translate: {translateAmount}px">

            <p class="text-white text-[3rem] font-bold">wanna try again?</p>
            <p class="text-white text-[3.4rem] font-bold moving-text">
                <a href="/play" on:click|preventDefault={restartGame} class="flex">
                    <TextAnimaiton text=">>>>" />
                </a>
            </p>
        </div>
    {:else if $gameStatus.opponent_lives !== null}
        <div 
            class="absolute inset-x-0 top-[13rem] stroke-text flex flex-col items-center justify-center vt323-regular"
            >
            <p class="text-white text-[6rem] text-center font-bold leading-[6rem]"
                >
                press<br />
                <TextAnimaiton text="[spacebar]" />
                to shoot<br />
            </p>
        </div>
    {:else}
        <div 
            class="absolute inset-x-0 top-[5rem] stroke-text flex flex-col items-center justify-center vt323-regular"
            >
            <img class="w-fit h-[25rem] object-cover" src="/assets/text-start-game.png" alt="Random">
            <p class="mt-[10rem] text-white text-[6rem] text-center font-bold leading-[6rem]"
                >
                <a href="#" on:click|preventDefault={startGame}>
                    <TextAnimaiton text="YES" />
                </a>
            </p>
        </div>

    {/if}
    <div class="absolute bottom-0 right-0 stroke-text flex flex-col items-center justify-end vt323-regular">
        {#if $gameStatus.opponent_lives !== null}

            <p class="mt-[10rem] text-white text-[4rem] text-center font-bold leading-[4rem]">
                {#if $gameStatus.opponent_hit === "hit"}
                        opponent<br />
                        hit
                {:else if $gameStatus.opponent_hit === "missed"}
                        opponent<br />
                        miss
                {/if}
            </p>
            <Progressbar 
                progress="{$gameStatus.opponent_lives}" 
                animate
                tweenDuration={1500}
                easing={sineOut}
                size="h-3 w-[25rem]" 
                color="red" 
                class="my-2" />
            {#if $gameStatus.opponent_shot}
                {#if $isOpponentDead}
                    <FallAnimation classes="w-fit h-[25rem] min-h-[25rem] max-h-[25rem]" character="opponent" />
                {:else}
                    <ShootAnimation classes="w-fit h-[25rem] min-h-[25rem] max-h-[25rem]" character="opponent" />
                {/if}
            {:else}
                <img class="w-fit h-[25rem]" src="/assets/opponent/pose-opponent-wait.gif" alt="opponent wait pose">
            {/if}
        {/if}
    </div>

    <div class="absolute bottom-10 left-20 stroke-text flex flex-col items-center justify-end vt323-regular">
        {#if $gameStatus.player_lives !== null}
            <p class="mt-[10rem] text-white text-[4rem] text-center font-bold leading-[4rem]">
                {#if $gameStatus.player_hit === "hit"}
                        you<br />
                        hit
                {:else if $gameStatus.player_hit === "missed"}
                        you<br />
                        miss
                {/if}
            </p>

            <Progressbar 
                progress="{$gameStatus.player_lives}" 
                animate
                tweenDuration={1500}
                easing={sineOut}
                size="h-3 w-[20rem]" 
                color="blue" 
                class="my-12" />
            {#if $gameStatus.player_shot}
                {#if $isPlayerDead}
                    <FallAnimation classes="w-fit h-[17rem]" character="player" />
                {:else}
                    <ShootAnimation classes="w-fit h-[17rem]" character="player" />
                {/if}
            {:else}
                <img class="w-fit h-[17rem]" src="/assets/player/pose-player-wait.gif" alt="player wait pose">
            {/if}
        {/if}
    </div>

</div>

<style>
    div{
		transform: translate(var(--translate))
    }
</style>