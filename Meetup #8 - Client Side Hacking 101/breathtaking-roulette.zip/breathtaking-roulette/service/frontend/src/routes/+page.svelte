<script lang="ts">
    import TextAnimaiton from '$lib/components/TextAnimaiton.svelte';
</script>

<svelte:head>
	<title>Cowboy Games</title>
</svelte:head>

<div class="relative w-full h-screen">
    <img class="w-full h-full object-cover" src="/assets/bg/bg-start-screen.png" alt="Random">
    <div class="absolute inset-0 flex justify-center top-[3rem]">
        <img class="w-fit h-[25rem] object-cover" src="/assets/text-cowboy-games.png" alt="Random">
    </div>
    <div class="absolute inset-0 bottom-[7rem] left-[10rem] stroke-text flex flex-col items-center justify-end vt323-regular">
        <p class="text-white text-[5rem] font-bold">let's play</p>
        <p class="text-white text-[5rem] font-bold moving-text">
            <a href="/play" class="flex">
                <TextAnimaiton text=">>>>" />
            </a>
        </p>
    </div>

</div>