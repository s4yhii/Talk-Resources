<script lang="ts">
    import TextAnimaiton from '$lib/components/TextAnimaiton.svelte';
</script>

<svelte:head>
	<title>Why are you here?</title>
</svelte:head>

<div class="relative w-full h-screen">
    <img class="w-full h-full object-top object-cover" src="/assets/bg/bg-game-over.png" alt="game over screen">
    <div class="absolute right-5 bottom-5">
        <p class="bg-gradient-to-r from-orange-600 via-red-500 to-orange-400 inline-block text-transparent bg-clip-text moving-text">
	<TextAnimaiton classes="char bg-gradient-to-r from-orange-600 via-red-500 to-orange-400 inline-block text-transparent bg-clip-text moving-text" text="suffering" />
        </p>
    </div>
</div>
