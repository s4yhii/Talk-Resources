# app.py

from flask import Flask, jsonify, render_template, session, request
from flask_socketio import SocketIO, emit, join_room, leave_room
from time import sleep
import random, string

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'
socketio = SocketIO(app, async_mode='threading', path='/api/socket.io')

# Game state
game_rooms = {}

@socketio.on('connect')
def handle_connect():
    print('Client connected:', request.sid)

@socketio.on('disconnect')
def handle_disconnect():
    print('Client disconnected:', request.sid)

@socketio.on('join_game')
def join_game(data):
    room = data['room']
    session['room'] = room
    join_room(room)
    if room not in game_rooms:
        game_rooms[room] = {'player_lives': 100, 'opponent_lives': 100, 'shot_made': False,
                            'player_shot': False, 'player_hit': False, 'opponent_shot': False, 'opponent_hit': False}
    emit('game_status', game_rooms[room], room=room)

@socketio.on('shot')
def handle_shot():
    room = session['room']
    if game_rooms[room]['shot_made']:
        return
    # message = ""
    flag = "";
    success = random.random() < 1/6  # 1/6 probability of success
    opponent_success = random.random() < 1/4  # 1/6 probability of success
    game_rooms[room]['player_shot'] = True
    game_rooms[room]['opponent_shot'] = True
    if success:
        game_rooms[room]['opponent_lives'] -= 90
        game_rooms[room]['player_hit'] = "hit"
        opponent_success = True
    else:
        game_rooms[room]['player_hit'] = "missed"
    
    if opponent_success:
        sleep(0.15)
        game_rooms[room]['player_lives'] -= 100
        game_rooms[room]['shot_made'] = True
        game_rooms[room]['opponent_hit'] = "hit"
    else:
        game_rooms[room]['opponent_hit'] = "missed"
    
    if game_rooms[room]['player_lives'] <= 0:
        if game_rooms[room]['opponent_lives'] <= 0:
            flag = "CTFZone{n0vv_1_b3l13v3_th4t_y0u_4r3_f4st_8405d729e872fc}"
        game_over(room)
    
    emit('game_status', game_rooms[room], room=room)
    emit('shot_result', {'success': success, 'flag': flag}, room=room)  # Emit shot result with personalized message

def game_over(room):
    emit('game_over', room=room)
    
def generate_room_id():
    x1 = ''.join(random.choices(string.ascii_letters + string.digits, k=8))
    x2 = ''.join(random.choices(string.ascii_letters + string.digits, k=8))
    x3 = ''.join(random.choices(string.ascii_letters + string.digits, k=8))
    x4 = ''.join(random.choices(string.ascii_letters + string.digits, k=8))
    return x1 + '-' + x2 + '-' + x3 + '-' + x4

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/start', methods=['POST'])
def start_game():
    
    room = 'game_room_' + generate_room_id()
    session['room'] = room
    return jsonify({'room': room})

if __name__ == '__main__':
    socketio.run(app, '0.0.0.0', '5000', debug=False)
